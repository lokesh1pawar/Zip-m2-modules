<?php

use Magento\Catalog\Model\Product\Type as ProductType;

/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
// declare(strict_types=1);

namespace Roki\ProducersTag\Observer\Frontend\Catalog;

class ControllerProductInitAfter implements \Magento\Framework\Event\ObserverInterface
{

    /**
     * Execute observer
     *
     * @param \Magento\Framework\Event\Observer $observer
     * @return void
     */
    public function execute(
        \Magento\Framework\Event\Observer $observer
    ) {
        
        if($product){

             $this->_redirect('home');

            $writer = new \Zend\Log\Writer\Stream(BP.'/var/log/roki.log'); 
            $logger = new \Zend\Log\Logger();
            $logger->addWriter($writer);
            $logger->info("Observer called");       
        }
    }
}
