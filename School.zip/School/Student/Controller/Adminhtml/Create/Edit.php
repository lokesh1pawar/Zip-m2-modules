<?php
namespace School\Student\Controller\Adminhtml\Create;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;

class Edit extends Action
{
    public $blogFactory;
    public $resultPageFactory;

    
    public function __construct(
        Context $context,
        \School\Student\Model\ViewFactory $blogFactory, 
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Magento\Framework\Registry $registry
    ) {
        $this->blogFactory = $blogFactory;
        $this->resultPageFactory = $resultPageFactory;
        $this->_registry = $registry;
        parent::__construct($context,$registry);

    }

    public function execute()
    {
        //$resultRedirect = $this->resultRedirectFactory->create();

        $resultPage = $this->resultPageFactory->create();

         $id = $this->getRequest()->getParam('id');
        //exit;
        try {
            $blogModel = $this->blogFactory->create();
            $blogModel->load($id);
            
            $this->_registry->register('school_student_create', $blogModel);
           
            //$blogModel->load($id)->setId($id)->setTitle('Cricket')->setContent('Outside game to play with 11 players')->save();  



           // $this->messageManager->addSuccessMessage(__('You Edited the Article.'));
        } catch (\Exception $e) {
            //$this->messageManager->addErrorMessage($e->getMessage());
        }
        //return $resultRedirect->setPath('*/*/');
        return $resultPage;
    }

    public function _isAllowed()
    {
        return $this->_authorization->isAllowed('Vendor_Module::delete');
    }
}