<?php

namespace Roki\GuidedFlow\Model;
use Magento\Framework\Model\AbstractModel;

class TreeModel extends \Magento\Framework\Model\AbstractModel {

    protected function _construct() {
        $this->_init('Roki\GuidedFlow\Model\ResourceModel\TreeModel');
    }
}