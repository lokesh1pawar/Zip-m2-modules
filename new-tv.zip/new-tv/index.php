<html>  
    <head>  
        <title> TreeView </title>  
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" /> 
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-treeview/1.2.0/bootstrap-treeview.min.css" />

        <!-- <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>   -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script> 
      <script type="text/javascript" charset="utf8" src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.9.1.min.js"></script>

        <!-- for treeview -->
        <script type="text/javascript" charset="utf8" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-treeview/1.2.0/bootstrap-treeview.min.js"></script>

    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
    <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css"> -->
    <style>
    #buttonsss{
        display: flex;
        justify-content: space-between;
        align-items: center; }
</style>

    </head>  
    <body>  
        <div class="container"> 
            <!-- Modal for insert data  -->
<div id="create-modal" class="modal fade" role="dialog">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<a class="close" data-dismiss="modal">x</a>
                <h3>Add a Tree</h3>
			</div>
			<form id="addDataForm" name="add" role="form">
				<div class="modal-body">				
					<div class="form-group">
						<label for="name">Tree Name</label>
						<input type="text" name="tree" class="form-control">
					</div>
					<div class="form-group">
						<label for="number">Parent ID</label>
						<input type="number" name="parent_id" class="form-control">
					</div>				
				</div>
				<div class="modal-footer">					
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					<input type="submit"  data-backdrop="static" class="btn btn-success" id="submit">
				</div>
			</form>
		</div>
	</div>
</div> 
   <!-- modal insert end -->
            <br />  
            <br />
			<br />
			<div class="table-responsive">  
			<div id="buttonsss">
        	<h3 >Tree List</h3>

            <div id="treedata"><button type="button" class="btn btn-primary" data-toggle="modal" data-target="#create-modal">Create Tree</button></div></div>
                <br />
				<span id="result"></span>
				<div id="live_data"></div>                 
			</div>  
		</div>

        <!-- For Tree  -->

        <div class="container">
         <!-- <div class="panel panel-default"> -->
          <!-- <div class="panel-heading">
           <h4>Treeview</h4>
        </div> -->
     <!-- <div class="panel-body">
        <div class="col-md-8" id="treeview_json">
       </div>
     </div> -->
     <!-- </div> -->

     <!-- <div id="treeview"></div> -->
     <div id="tree">
         <!-- <h1>lokesh</h1> -->
     </div>

    </div>
        </div>

      <!-- </div> -->
<!-- <?php  include 'fetch.php'; ?> -->
      <!-- Modal Edit HTML -->
    <div id="myModal" class="modal fade" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
           
            <div class="modal-header">
				<a class="close" data-dismiss="modal">x</a>
                <h3>Edit a Tree</h3>
			</div>
			<form id="updateDataForm" name="add" role="form">
				<div class="modal-body">				
					<div class="form-group">
						<label for="name">Node Name</label>
        <input type="hidden" name="node_id" value="<?php echo $nid; ?>" class="form-control"> <!-- id  -->
			<input type="text" name="node_tree" value="<?php echo $row['tree']; ?>" class="form-control">
					</div>
					<div class="form-group">
						<label for="number">Parent ID</label>
			<input type="number" name="node_parent_id" value="<?php echo $row['parent_id']; ?>" class="form-control">
					</div>				
				</div>
				<div class="modal-footer">					
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					<input type="submit"  data-backdrop="static" class="btn btn-success" id="submit">
				</div>
			</form>   
              
            
        </div>
    </div>
</div>
    </body>  
</html>  
<script>  
$(document).ready(function(){  
    function fetch_data()  
    {  
        $.ajax({  
            url:"select.php",  
            method:"POST",  
            success:function(data){  
				$('#live_data').html(data);  
            }  
        });  
    }  
    fetch_data();  
    
	function edit_data(id, text, column_name)  
    {  
        $.ajax({  
            url:"edit.php",  
            method:"POST",  
            data:{id:id, text:text, column_name:column_name},  
            dataType:"text",  
            success:function(data){  
                //alert(data);
				$('#result').html("<div class='alert alert-success'>"+data+"</div>");
            }  
        });  
    }  
    $(document).on('blur', '.tree', function(){  
        var id = $(this).data("id1");  
        var first_name = $(this).text();  
        edit_data(id, first_name, "tree");  
    });  
    // $(document).on('blur', '.last_name', function(){  
    //     var id = $(this).data("id2");  
    //     var last_name = $(this).text();  
    //     edit_data(id,last_name, "last_name");  
    // });  
    $(document).on('click', '.btn_delete', function(){  
        var id=$(this).data("id3");  
        if(confirm("Are you sure you want to delete this?"))  
        {  
            $.ajax({  
                url:"delete.php",  
                method:"POST",  
                data:{id:id},  
                dataType:"text",  
                success:function(data){  
                    alert(data);  
                    fetch_data();  
                }  
            });  
        }  
    });  
});  

// for modal 
$(document).ready(function(){	
	$("#addDataForm").submit(function(event){
        // event.preventDefault();
		submitForm();
		// return false;
	});
});

function submitForm(){
	 $.ajax({
		type: "POST",
		url: "insert.php",
		cache:false,
		data: $('form#addDataForm').serialize(),
		success: function(response){
			$("#treedata").html(response)
			// $("#create-modal").modal('hide');
		},
		error: function(){
			alert("Error");
		}
	});
}

// For Tree 

// $(document).ready(function(){
  
//   var treeData;
  
//   $.ajax({
//        type: "GET",  
//        url: "treeview.php",
//        dataType: "json",       
//        success: function(response)  
//        {
//          initTree(response)
//        }   
//  });
  
//  function initTree(treeData) {
//    $('#treeview_json').treeview({data: treeData});
//  }
  
// });

fill_parent_category();

  fill_treeview();
  
  getTree(); 

//   getSelected();

  
  function fill_treeview()
  {
   $.ajax({
    url:"fetch.php",
    dataType:"json",
    success:function(data){
     $('#treeview').treeview({
      data:data
     });
    }
   })
  }

  function fill_parent_category()
  {
   $.ajax({
    url:'fill_parent_category.php',
    success:function(data){
     $('#parent_category').html(data);
    }
   });
   
  }

  function getTree() {
   $.ajax({
    url:"fetch.php",
    dataType:"json",
    success:function(data){  
    $('#tree').treeview({
        data:data
});
// console.log("arha hai");
 
}
   });
}

// For click Event 

// $("#tree").on('click','.list-group-item', function () {
//                         // console.log($(this).html());
//                         $('#myModal').modal('show'); 

//  });
     
// function getSelected()
// {
    // $(document).ready(function(){	
    // $("#tree").click(function() {
    //     alert($('.list-group .node-tree').text());
    //     console.log("hii");
    // });

// });
// }
    

$('#tree').mousedown(function(event) {
    switch (event.which) {
        case 1:
            // alert('Left Mouse button pressed.');
            break;
        case 2:
            // alert('Middle Mouse button pressed.');
            break;
        case 3:
            $('#myModal').modal('show'); 
            break;
        default:
            alert('You have a strange Mouse!');
    }
});

// For Selecting Node ID 

// $(function () {

//    $('#tree').treeview({

//         // color: "#428bca",
//         // data: defaultData,
//         // levels: 2,
//  onNodeSelected: function(event, data) {
//         alert('selected:')
//     }
//     });
// });


// $(document).ready(function() {
// //   console.log($('#tree').attr('id'));
//     $('#tree').treeview({
//   onNodeSelected: function(event, data) {
//     //   console.log('getting');
//     alert('selected:')
//   }
// });
// });

$(document).ready(function(){
      
    $('.list-group li').on('click',function(){
    var a = $(this).data('nodeid');
        
    // var a = $('#tree').attr('data-nodeid');
    alert(a);
     console.log("ok");
    });
    // console.log(a);

    // var a = $('#tree').text();
    // console.log(a);

});


//  For Update Node 

function updateForm(){
	 $.ajax({
		type: "POST",
		url: "update_node.php",
		cache:false, 
		data: $('form#updateDataForm').serialize(),
		success: function(response){
			$("#myModal").html(response)
			// $("#create-modal").modal('hide');
		},
		error: function(){
			alert("Error");
		}
	});
}

</script>
