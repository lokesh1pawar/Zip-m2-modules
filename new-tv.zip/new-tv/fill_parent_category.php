<?php

$connect = new PDO("mysql:host=mysql; dbname=treeview", "root", "docker");

$query = "SELECT * FROM data_tv ORDER BY tree ASC";

$statement = $connect->prepare($query);

$statement->execute();

$result = $statement->fetchAll();

$output = '<option value="0">Parent Category</option>';

foreach($result as $row)
{
 $output .= '<option value="'.$row["id"].'">'.$row["tree"].'</option>';
}

echo $output;

?>
