<?php  

if (isset($_POST['tree'])) {
     $tree = strip_tags($_POST['tree']);
	$parent = strip_tags($_POST['parent_id']);	
     
     $connect = mysqli_connect("mysql", "root", "docker", "treeview");
$sql = "INSERT INTO data_tv(tree, parent_id) VALUES('".$_POST["tree"]."','".$_POST["parent_id"]."')";  
if(mysqli_query($connect, $sql))  
{  
     echo "<script>alert('Data Submitted')</script>";
}  
}
 ?>