<?php  

if (isset($_POST['tree'])) {
    $id = ($_POST['node_id'])
     $tree = ($_POST['node_tree']);
	$parent = ($_POST['node_parent_id']);	
     
     $connect = mysqli_connect("mysql", "root", "docker", "treeview");
$sql = "UPDATE data_tv SET tree='$tree', parent_id='$parent' WHERE id='$id' ";  
if(mysqli_query($connect, $sql))  
{  
     echo "<script>alert('Data Updated')</script>";
}  
}
 ?>