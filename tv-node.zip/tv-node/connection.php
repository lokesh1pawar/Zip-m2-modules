<?php


$connect = mysqli_connect("mysql:host=mysql; dbname=testing", "root", "docker");

?>