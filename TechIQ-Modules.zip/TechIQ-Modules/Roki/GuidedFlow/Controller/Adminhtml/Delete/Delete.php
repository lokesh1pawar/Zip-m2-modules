<?php
namespace Roki\GuidedFlow\Controller\Adminhtml\Delete;
class Delete extends \Magento\Backend\App\Action
{
         protected $resultPageFactory = false;      
         public function __construct(
                 \Magento\Backend\App\Action\Context $context,
                 \Magento\Framework\View\Result\PageFactory $resultPageFactory
         ) {
                 parent::__construct($context);
                 $this->resultPageFactory = $resultPageFactory;
         } 
         public function execute()
         {
            // $connect = mysqli_connect("mysql", "root", "docker", "treeview");
            $sql = "DELETE FROM guidedflow WHERE id = '".$_POST["id"]."'";  
            if(mysqli_query($connect, $sql))  
            {  
                echo 'Data Deleted';  
            }    
         }
        
}

