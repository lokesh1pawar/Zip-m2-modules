<?php  
 $connect = mysqli_connect("mysql", "root", "docker", "treeview");  
 $output = '';  
 $sql = "SELECT * FROM data_tv ORDER BY id DESC";  
 $result = mysqli_query($connect, $sql);  
 $output .= '  
      <div class="table-responsive">  
           <table class="table table-bordered">  
                <tr>  
                     <th width="2%">Sno.</th>  
                     <th width="5%">Tree</th>  
                     <th width="2%">Delete</th>  
                </tr>';  
 $rows = mysqli_num_rows($result);
  
	  if($rows > 10)
	  {
		  $delete_records = $rows - 10;
		  $delete_sql = "DELETE FROM data_tv LIMIT $delete_records";
		  mysqli_query($connect, $delete_sql);
	  }
      while($row = mysqli_fetch_array($result))  
      {  
           $output .= '  
                <tr>  
                     <td>'.$row["id"].'</td>  
                     <td class="tree" data-id1="'.$row["id"].'" contenteditable>'.$row["tree"].'</td>  
                     <td><button type="button" name="delete_btn" data-id3="'.$row["id"].'" class="btn btn-xs btn-danger btn_delete">X</button></td>  
                </tr>  
           ';  
      }  
      $output .= '  
          
      ';  
 
 
 $output .= '</table>  
      </div>';  
 echo $output;  
 ?>