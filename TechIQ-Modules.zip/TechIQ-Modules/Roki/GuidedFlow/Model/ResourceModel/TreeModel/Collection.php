<?php

namespace Roki\GuidedFlow\Model\ResourceModel\TreeModel;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

class Collection extends AbstractCollection{
    protected function _construct()
    {
        $this->_init('Roki\GuidedFlow\Model\TreeModel', 'Roki\GuidedFlow\Model\ResourceModel\TreeModel');
    }
}