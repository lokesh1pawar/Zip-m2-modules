<?php

namespace School\Student\Controller\Rewrite\Index;


class Index extends \Sanjeev\Blog\Controller\Index\Index 
{
    
    public function execute()
    {
        echo "I'm inside Rewrite file"; 
        //exit;
        return parent::execute();
        //return $this->resultPageFactory->create();
    }
}