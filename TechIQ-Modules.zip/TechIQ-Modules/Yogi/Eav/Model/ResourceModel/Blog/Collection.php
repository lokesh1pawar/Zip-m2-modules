<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Yogi\Eav\Model\ResourceModel\Blog;

class Collection extends \Magento\Eav\Model\Entity\Collection\AbstractCollection
{

    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init(
            \Yogi\Eav\Model\Blog::class,
            \Yogi\Eav\Model\ResourceModel\Blog::class
        );
    }
}

