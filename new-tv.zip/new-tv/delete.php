<?php  
	$connect = mysqli_connect("mysql", "root", "docker", "treeview");
	$sql = "DELETE FROM data_tv WHERE id = '".$_POST["id"]."'";  
	if(mysqli_query($connect, $sql))  
	{  
		echo 'Data Deleted';  
	}  
 ?>