<?php
namespace School\Student\Controller\Adminhtml\Create;

use Magento\Backend\App\Action\Context;
use Magento\Framework\Controller\Result\JsonFactory;
use School\Student\Model\ViewFactory;

class InlineEdit extends \Magento\Backend\App\Action
{
    protected $jsonFactory;
    private $dataFactory;

    public function __construct(
        Context $context,
        JsonFactory $jsonFactory,
        ViewFactory $dataFactory)
    {
       parent::__construct($context);
       $this->jsonFactory = $jsonFactory;
       $this->dataFactory = $dataFactory;
    }

    public function execute()
    {
        $resultJson = $this->jsonFactory->create();
        $error = false;
        $messages = [];

       if ($this->getRequest()->getParam('isAjax')) {
            $postItems = $this->getRequest()->getParam('items', []);
            if (!count($postItems)) {
               $messages[] = __('Please correct the data sent.');
               $error = true;
           } else {
              foreach (array_keys($postItems) as $modelid) {
                $model = $this->dataFactory->create()->load($modelid);
                  try {
                    $model->setData(array_merge($model->getData(), $postItems[$modelid]));
                     $model->save();
                } catch (\Exception $e) {
                   $messages[] = "[Customform ID: {$modelid}] {$e->getMessage()}";
                   $error = true;
                 }
             }
         }
     }


return $resultJson->setData([
'messages' => $messages,
'error' => $error]);
} 
}