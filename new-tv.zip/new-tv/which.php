<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>event.which demo</title>
  <script src="https://code.jquery.com/jquery-3.5.0.js"></script>
</head>
<body>
 <div class="con">

   <ul id="list">
     <li>Audi</li>
     <li class="two">BMW</li>
     <li>Volvo</li>
     <li>Buggati</li>
   </ul>
 </div>
 
<script>
$(".con").dblclick(function() {
   alert($('#list .two').text());
});
</script>
 
</body>
</html>