<?php

namespace Plumtree\Ga4\Block;

use \Magento\Framework\View\Element\Template;
use \Plumtree\Ga4\Helper\Data;

class SocialHeader extends Template
{
    /**
     * @var Helper
     */
    private $helper;
    
    /**
     * @param Template\Context $context
     * @param Helper $helper
     * @param array $data
     */
    public function __construct(
        Template\Context $context,
        Data $helper,
        array $data = []
    ) {
        $this->helper = $helper;
        parent::__construct($context, $data);
    }

    /**
     * @return string
     */
    public function getGa4Status()
    {
        return $this->helper->getGa4Status();
    }

    /**
     * @return string
     */
    public function getGa4Id()
    {
        return $this->helper->getGa4Id();
    }

    /**
     * @return string
     */
    public function getGa4ConversionStatus()
    {
        return $this->helper->getGa4ConversionStatus();
    }

}
