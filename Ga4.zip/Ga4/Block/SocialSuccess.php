<?php

namespace Plumtree\Ga4\Block;

use \Magento\Framework\View\Element\Template;
use \Plumtree\Ga4\Helper\Data;
use \Magento\Sales\Model\OrderFactory;
use \Magento\Checkout\Model\Session;

class SocialSuccess extends Template
{
    /**
     * 
     */
    private $rule;  

    /**
     * 
     */
    private $_categoryFactory;  

    /**
     * @var Helper
     */
    private $helper;

    /**
     * @var \Magento\Sales\Model\OrderFactory
     */
    private $_orderFactory;

    /**
     * @var Session
     */
    private $session;     
    
    /**
     * @param Helper $helper
     * @param Order $order
     * @param Session $session
     * @param array $data
     */
    public function __construct(
        \Magento\SalesRule\Model\RuleFactory $rule,
    	\Magento\Catalog\Model\CategoryFactory $categoryFactory,
        Template\Context $context,
        Data $helper,
        \Magento\Sales\Model\OrderFactory $orderFactory,
        Session $session,
        array $data = []
    ) {
        $this->rule = $rule;
        $this->_categoryFactory = $categoryFactory;
        $this->helper = $helper;       
        $this->_orderFactory = $orderFactory;
        $this->session = $session;
        parent::__construct($context, $data);
    }

    /**
    * Retrieve current order
    *
    * @return \Magento\Sales\Model\Order
    */
    public function getOrderSubtotal()
    {
       $orderId = $this->session->getLastOrderId();
       $order   = $this->_orderFactory->create()->load($orderId);
       return $order->getSubtotal(); // you can access various order details from here. 
    }

    /**
     * @return string
     */
    public function getOrderNumber()
    {
        $order = $this->session->getLastRealOrder();
        return $order->getIncrementId();
    }
    
    /**
     * @return string
     */
    public function getGa4Status()
    {
        return $this->helper->getGa4Status();
    }

    /**
     * @return string
     */
    public function getGa4ConversionStatus()
    {
        return $this->helper->getGa4ConversionStatus();
    }   

    /**
     * @return array
     */
    public function getGtmPurchaseCode()
    {
        $orderInfo = [];
        $items = [];
        $count = 0;
        $orderId = $this->session->getLastOrderId();
        $order   = $this->_orderFactory->create()->load($orderId);
        $orderInfo['transaction_id'] = $order->getIncrementId();
        $orderInfo['value']  = number_format($order->getSubtotal(),2);

        if($order->getTaxAmount()){
            $orderInfo['tax']    = number_format($order->getTaxAmount(),2);
        }

        $orderInfo['shipping'] = number_format($order->getShippingInclTax(),2);
        
        if($order->getCouponCode()){
            $orderInfo['coupon'] = $order->getCouponCode();
        }
        
        foreach ($order->getAllVisibleItems() as $key => $item) {
            $items['item_id'] = $item->getSku();
            $items['item_name'] = $item->getName();

            if($item->getAppliedRuleIds()){
                $salesruleIds = (int)$item->getAppliedRuleIds();
                $couponCodeData = $this->rule->create()->load($salesruleIds);
                $items['coupon']  = $couponCodeData->getCouponCode();
            }
		
            $items['currency'] = "USD";
            $items['discount_amount'] = number_format($item->getDiscountAmount(),2);
            $items['index'] = $count;    
            $items['item_brand'] = $item->getProduct()->getAttributeText('manufacturer');
	    
	        $categories = $item->getProduct()->getCategoryIds();
    	foreach ($categories as $index => $id) {
    	    	if ($index == 0) {
    	    		$items['item_category'] = $this->getCategoryName($id);
    	    	} else {
    	    		$items['item_category_'.$index] = $this->getCategoryName($id);
    	    	}
	    }
    		$items['price'] = number_format($item->getPrice(),2);
    	    $items['quantity'] = $item->getQtyOrdered();
            $orderInfo['items'][] = $items;
            
            $count++;
        }
        
        return $orderInfo;
    }      
    
    public function getCategoryName($catId)
    {
        $category = $this->_categoryFactory->create()->load($catId);
        return $category->getName();
    } 
    
}
