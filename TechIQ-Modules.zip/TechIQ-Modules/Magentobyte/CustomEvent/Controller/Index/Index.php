<?php
namespace Magentobyte\CustomEvent\Controller\Index;

use Magento\Framework\DataObject;
use Magento\Framework\App\Action\Action;

class Index extends Action
{
    public function execute()
    {
        $customData = new DataObject(['record_id' => '10001', 'name' => 'record_name']);

        // define custom event name with array data
        $this->_eventManager->dispatch('jesadiya_custom_event_observer',
            [
                'record' => $customData
            ]
        );
    }
}