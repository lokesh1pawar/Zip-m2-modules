<?php
namespace Roki\GuidedFlow\Controller\Adminhtml\Select;
class Select extends \Magento\Backend\App\Action
{
         protected $resultPageFactory = false;      
         public function __construct(
                 \Magento\Backend\App\Action\Context $context,
                 \Magento\Framework\View\Result\PageFactory $resultPageFactory
         ) {
                 parent::__construct($context);
                 $this->resultPageFactory = $resultPageFactory;
         } 
         public function execute()
         {
          //     echo "Select.php -> working";
        //     $connect = mysqli_connect("mysql", "root", "docker", "treeview");  


        $output = '';  
     //    $sql = "SELECT * FROM guidedflow ORDER BY id DESC";  
     //  $result = mysqli_query($connect, $sql);       
     // $collection = $this->getTestCollection();
     // $test->getCollection()->getData();
     //    $output .= '  
     //  <div class="table-responsive">  
     //       <table class="table table-bordered">  
     //            <tr>  
     //                 <th width="2%">Sno.</th>  
     //                 <th width="5%">Tree</th>  
     //                 <th width="2%">Delete</th>  
     //            </tr>';  
     //    $rows = mysqli_num_rows($result);
  
	//   if($rows > 10)
	//   {
	// 	  $delete_records = $rows - 10;
	// 	  $delete_sql = "DELETE FROM guidedflow LIMIT $delete_records";
	// 	  mysqli_query($connect, $delete_sql);
	//   }
     //  while($row = mysqli_fetch_array($result))  
     //  {  
     //       $output .= '  
     //            <tr>  
     //                 <td>'.$data->getId().'</td>  
     //                 <td class="tree" data-id1="'.$data->getId().'" contenteditable>'.$data->getTitle().'</td>  
     //                 <td><button type="button" name="delete_btn" data-id3="'.echo $data->getTitle().'" class="btn btn-xs btn-danger btn_delete">X</button></td>  
     //            </tr>  
     //       ';  
     //  }  
     //  $output .= '  
          
     //  ';  
 
 
     //    $output .= '</table>  
     //  </div>';  
     //    echo $output;  
         }
        
}