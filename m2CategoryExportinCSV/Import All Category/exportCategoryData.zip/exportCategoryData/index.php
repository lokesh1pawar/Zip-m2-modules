<?php

class CategoryExport {
	private $host 		= 'localhost';
	private $dbname 	= 'magento243';
	private $username 	= 'root';
	private $password 	= 'rot';
	public  $connection;
	public  $filename	= 'categoryData.csv';
	public  $data 		= ['Category Id', 'Category Name', 'Description', 'Meta Title', 'Meta Keywords', 'Meta Description', 'Status', 'Include In Menu', 'Image', 'Url Key'];
	
	public function __construct() {
		$this->connection = new mysqli($this->host,$this->username,$this->password,$this->dbname);
		if($this->connection->connect_error) {
			die('connection failed' . $this->connection ->connect_error);
		}else {
			//echo 'connected succesfully';
			return $this->connection;
		}
	}
	
	/**
	 * Write Category Data to CSV file
	 */
	public function exportInCSV() {
		$f = fopen($this->filename, 'w');

		if ($f === false) {
			die('Error opening the file ' . $this->filename);
		}
		fputcsv($f, $this->data);

		$dataCat = $this->getAllCategoryData();

		//echo "<pre>"; 	print_r($dataCat); echo "</pre>";

		foreach($dataCat as $data) {
			fputcsv($f, $data);
		}
		echo "<br><h2>Category Data Exported Successfully <a href='$this->filename'>Download File</a></h2>";
		fclose($f);
	}
	
	/*
	 * Get All Category Data
	 */
	public function getAllCategoryData() {
		$sql = "SELECT `entity_id`, `path` FROM `catalog_category_entity`";

		$result = $this->connection->query($sql);
		if($result->num_rows>0) {
			while($row = $result->fetch_assoc()) {
				$entityid = $row['entity_id'];
				$path 	  = $row['path'];

				$paths = explode('/', $path);

				$names = '';
				foreach ($paths as $id) {
					$names .= $this->getCategoryDetails($id, 'name');
					$names = $names . '/';
				}
				$names = rtrim($names, "/");
				$description = $this->getCategoryDetails($entityid, 'description');
				$metaTitle   = $this->getCategoryDetails($entityid, 'meta_title');
				$metaKey     = $this->getCategoryDetails($entityid, 'meta_keywords');
				$metaDes     = $this->getCategoryDetails($entityid, 'meta_description');
				$status      = $this->getCategoryDetails($entityid, 'is_active');
				$isInMenu    = $this->getCategoryDetails($entityid, 'include_in_menu');
				$image       = $this->getCategoryDetails($entityid, 'image');
				$urlKey      = $this->getCategoryDetails($entityid, 'url_key');

				$categyNames[$entityid] = [$entityid, $names, $description, $metaTitle, $metaKey, $metaDes, $status, $isInMenu, $image, $urlKey];
			}
			return $categyNames;
		}
	}	

	public function getCategoryDetails($entity_id, $attributeCode) {
		$attributeData = $this->getAttributeDetails($attributeCode);
		
		$attributeid   = $attributeData['attribute_id'];
		$tableName     = 'catalog_category_entity_'.$attributeData['backend_type'];

		$sql = "SELECT `value` FROM `$tableName` WHERE entity_id = $entity_id AND attribute_id = $attributeid";

		$result = $this->connection->query($sql);
		if($result->num_rows>0) {
			while($row = $result->fetch_assoc()) {
				$categyDesc = $row['value'];
			}
			return $categyDesc;
		}
	}

	public function getAttributeDetails($attributeCode) {
		$sql = "SELECT `attribute_id`, `backend_type` FROM `eav_attribute` WHERE attribute_code = '$attributeCode' AND entity_type_id = 3";

		$result = $this->connection->query($sql);
		if($result->num_rows>0) {
			while($row = $result->fetch_assoc()) {
				$attributeData['attribute_id'] = $row['attribute_id'];
				$attributeData['backend_type'] = $row['backend_type'];
			}
			return $attributeData;
		}
	}
}

$catExport = new CategoryExport();
$catExport->exportInCSV();