<?php

namespace School\Student\Model\ResourceModel;

/**
 * @api
 * @since 100.0.2
 */
class View extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    
    protected function _construct()
    {
        $this->_init('student_article', 'id'); // Table name and Primary Key
    }

    
}
