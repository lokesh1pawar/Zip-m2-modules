<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Yogi\Eav\Model;

use Magento\Framework\Api\DataObjectHelper;
use Yogi\Eav\Api\Data\BlogInterface;
use Yogi\Eav\Api\Data\BlogInterfaceFactory;

class Blog extends \Magento\Framework\Model\AbstractModel
{

    const ENTITY = 'yogi_blog_entity';
    protected $blogDataFactory;

    protected $dataObjectHelper;

    protected $_eventPrefix = 'yogi_blog_entity';

    /**
     * @param \Magento\Framework\Model\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param BlogInterfaceFactory $blogDataFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param \Yogi\Eav\Model\ResourceModel\Blog $resource
     * @param \Yogi\Eav\Model\ResourceModel\Blog\Collection $resourceCollection
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        BlogInterfaceFactory $blogDataFactory,
        DataObjectHelper $dataObjectHelper,
        \Yogi\Eav\Model\ResourceModel\Blog $resource,
        \Yogi\Eav\Model\ResourceModel\Blog\Collection $resourceCollection,
        array $data = []
    ) {
        $this->blogDataFactory = $blogDataFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        parent::__construct($context, $registry, $resource, $resourceCollection, $data);
    }

    /**
     * Retrieve blog model with blog data
     * @return BlogInterface
     */
    public function getDataModel()
    {
        $blogData = $this->getData();
        
        $blogDataObject = $this->blogDataFactory->create();
        $this->dataObjectHelper->populateWithArray(
            $blogDataObject,
            $blogData,
            BlogInterface::class
        );
        
        return $blogDataObject;
    }
}

