<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Yogi\Eav\Setup;

use Magento\Eav\Setup\EavSetup;

class BlogSetup extends EavSetup
{

    public function getDefaultEntities()
    {
        return [
             \Yogi\Eav\Model\Blog::ENTITY => [
                'entity_model' => \Yogi\Eav\Model\ResourceModel\Blog::class,
                'table' => 'yogi_blog_entity',
                'attributes' => [
                    'title' => [
                        'type' => 'static'
                    ]
                ]
            ]
        ];
    }
}

