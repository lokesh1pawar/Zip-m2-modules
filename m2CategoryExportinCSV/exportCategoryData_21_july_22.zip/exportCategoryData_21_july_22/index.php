<?php

class CategoryExport {
	private $host 		= 'localhost';
	private $dbname 	= 'magento243';
	private $username 	= 'root';
	private $password 	= 'rot';
	public $connection;
	public $filename	= 'stock.csv';
	public $data 		= ['Category Id', 'Category Name', 'Desc'];
	public $count = 0;
	
	
	public function __construct() {
		$this->connection = new mysqli($this->host,$this->username,$this->password,$this->dbname);
		if($this->connection->connect_error) {
			die('connection failed' . $this->connection ->connect_error);
		}else {
			echo 'connected succesfully';
			return $this->connection;
		}
	}
	
	public function exportInCSV($connection, $filename, $data) {
		$f = fopen($filename, 'w');

		if ($f === false) {
			die('Error opening the file ' . $filename);
		}
		fputcsv($f, $data);

		$dataCat = $this->getCategoryData($connection);
		$dataCatDesc = $this->getCategoryDesc($this->connection);

		foreach ($dataCatDesc as $row) {
			fputcsv($f, $row);
		}
		fclose($f);
	}
	
	function getCategoryData($connection) {
		$this->SELECT = "select entity_id,value FROM `catalog_category_entity_varchar`
		WHERE attribute_id = 45
		AND store_id = 0";

		$this->result = $connection->query($this->SELECT);
		if($this->result->num_rows>0) {
			while($this->row=$this->result->fetch_assoc()) {
				$this->entityid = $this->row['entity_id'];
				$this->value = $this->row['value'];		
				$this->mydataarray[$this->entityid]=[$this->entityid,$this->value];
				//print_r($mydataarray);
				$this->count++;
			}
			return $this->mydataarray;
		}
	}
	
	function getCategoryDesc($connection) {
		$this->catDe = "select entity_id, value FROM `catalog_category_entity_text`
		WHERE attribute_id = 47
		AND store_id = 0";

		$this->count = 2;
		$this->resultDe = $connection->query($this->catDe);
		if($this->resultDe->num_rows>0) {
			while($this->rowDe=$this->resultDe->fetch_assoc()) {
				$this->mydataarray[$this->rowDe['entity_id']][$this->count]=$this->rowDe['value'];
				//$this->count++;
			}
			echo "<pre>";
		print_r($this->mydataarray);
		echo "</pre>";
			return $this->mydataarray;
		}
	}
}

$catExport = new CategoryExport();
$catExport->exportInCSV($catExport->connection, $catExport->filename, $catExport->data);