<?php

if(isset($_POST['submit'])){

$name = $_POST['name'];
$phone = $_POST['phone'];
$message = $_POST['message'];

// if (empty($name) || empty($phone)){
//     echo "<script type='text/javascript'>alert('Please fill all fields.'); 
//     window.history.log(-1);
//     </script>";
// }
// else
// {
    mail("lokesh1pawar@gmail.com", "From:" , $name , "Phone No:" , $phone , "Message:" , $message);
    echo "<script type='text/javascript'>alert('Message Sent :‑)');
    window.location = 'contact.html';
    </script>";

// }
}
?>