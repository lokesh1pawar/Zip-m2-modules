<?php

  $connection = dbconnection();

  $data = [
  ['Symbol', 'Company', 'Price'],
  ['GOOG', 'Google Inc.', '800'],
  ['AAPL', 'Apple Inc.', '500'],
  ['AMZN', 'Amazon.com Inc.', '250'],
  ['YHOO', 'Yahoo! Inc.', '250'],
  ['FB', 'Facebook, Inc.', '30'],
];

$filename = 'stock.csv';

// open csv file for writing
$f = fopen($filename, 'w');

if ($f === false) {
  die('Error opening the file ' . $filename);
}

// write each row at a time to a file
 $data = getCategoryId($connection);
 print_r($data);
foreach ($data as $row) {
  fputcsv($f, $row);
}

// close the file
fclose($f);

  /*if (($open = fopen("book1.csv", "r")) !== FALSE) 
  {
  
    while (($data = fgetcsv($open, 1000, ",")) !== FALSE) 
    {    
      //echo $data[0];    
      $categoryId = getCategoryId($connection,$data[0]);

      print_r($categoryId);
      if($categoryId) {
        //insertCategoryDes($connection,$categoryId,$data[1]);

         $data = $categoryId;
      }
      //$array[] = $data; 
    }
  
    fclose($open);
  }*/
  function dbconnection() {
      $host = 'localhost';
      $dbname = 'magento2';
      $username = 'root';
      $password = 'admin@123';

      $connection = new mysqli($host,$username,$password,$dbname);
      if($connection->connect_error) {
          die('connection failed' . $connection ->connect_error);
      }else {
        echo 'connected succesfully';
        return $connection;
      }
  }

    function getCategoryId($connection) {
      $SELECT = "select entity_id,value FROM `catalog_category_entity_varchar`
      WHERE attribute_id = 45
      AND store_id = 0";
      

      $result = $connection->query($SELECT);
      if($result->num_rows>0) {
        while($row=$result->fetch_assoc()) {
            $entityid = $row['entity_id'];
            $value = $row['value'];
           $mydataarray=array([$entityid,$value]);

           //print_r($mydataarray);

        }

return $mydataarray;
      }    
  }

 
