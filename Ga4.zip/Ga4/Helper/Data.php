<?php

namespace Plumtree\Ga4\Helper;

use Magento\Framework\App\Helper\AbstractHelper;
use \Magento\Framework\App\Helper\Context;
use \Magento\Framework\App\Config\ScopeConfigInterface;

class Data extends AbstractHelper
{
    const XML_PATH_GA4_STATUS = 'social_codes/ga4/status';
    
    const XML_PATH_GA4_ID = 'social_codes/ga4/ga4_id';

    const XML_PATH_GA4_CONVERSION_STATUS = 'social_code/ga4/ga4_conversion';

    /**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected $scopeConfig;

    /**
     * @param Context $context
     * @param ScopeConfigInterface $scopeConfig
     */
    public function __construct(
        Context $context,
        ScopeConfigInterface $scopeConfig
    ) {
        parent::__construct($context);
        $this->scopeConfig = $scopeConfig;        
    }

    /**
     * @return string
     */
    public function getGa4Status()
    {
        return $this->scopeConfig->getValue(
            self::XML_PATH_GA4_STATUS,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

    /**
     * @return string
     */
    public function getGa4Id()
    {
        return $this->scopeConfig->getValue(
            self::XML_PATH_GA4_ID,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

    /**
     * @return string
     */
    public function getGa4ConversionStatus()
    {
        return $this->scopeConfig->getValue(
            self::XML_PATH_GA4_CONVERSION_STATUS,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

}
